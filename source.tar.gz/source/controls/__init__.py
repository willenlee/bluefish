#from bottle import Bottle, template, request,static_file
#from bottle import template

#app = Bottle(__name__)

#import redfish.views
